# TinyProof — Starter Prototype

TinyProof is a mobile-first proof-of-ability portfolio prototype.

## Features
- Challenge discovery, search, and skill filters
- Challenge briefs and completion criteria
- Create, edit, revise, and delete local submissions
- Draft/submitted status
- Feedback notes
- Local creator profile and portfolio preview
- Share summaries using the device share sheet or clipboard
- Responsive layout and basic PWA manifest/service worker

## Important limits
This first version stores submissions and profile data in the current browser's localStorage. It does not provide real accounts, cloud sync, shared global profiles, private backend storage, automated AI evaluation, or payments. The share action shares a text summary; it does not publish a public profile URL.

## Run locally
Open `index.html` in a modern browser. PWA installation and service-worker offline caching generally require HTTPS or localhost; they won't activate when opening the file directly.

## Free hosting
Create a GitHub repository, upload `index.html`, `manifest.json`, `sw.js`, and this README, then enable GitHub Pages in repository settings. Confirm the resulting public page before sharing it.
